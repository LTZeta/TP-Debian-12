history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
nano /etc/hosts
nano /etc/hosts
hostnamectl
apt get-update
apt update
ip addr
ip route
ping 8.8.8.8
clear
cat /etc/resolv.conf
echo "nameserver 8.8.8.8" > /etc/resolv.conf 
cat /etc/resolv.conf
ping deb.debian.org
clear
cat /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
cat /etc/apt/sources.list}
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt clean
apt update
apt update
apt install nano
nano /etc/hosts
cat /etc/apt/sources.list
cat /etc/debian_version 
cat /etc/os-release 
clear
nano /etc/apt/sources.list
fg 1
apt update
apt upgrade -y
lsblk
fdisk -l
apt full-upgrade -y
reboot
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys 
clear
chmod 600 /root/.ssh/authorized_keys
nano /etc/ssh/sshd_config
clear
systemctl restart ssh
systemctl status ssh
grep -E "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
ls -la /root/.ssh
exit
clear
exit
clear
exit
ssh -i /root/clave_privada.txt root@localhost
exit
exit
nano /etc/ssh/sshd_config
clear
nano /root/clave_publica.pub
clear
nano /root/clave_publica.pub
nano /root/clave_privada.txt
clear
chmod 600 /root/clave_privada
chmod 644 /root/clave_publica.pub
chmod 600 /root/clave_privada.txt
chmod 644 /root/clave_publica.pub}
chmod 644 /root/clave_publica.pub
clear
ssh -i /root/clave_privada root@localhost
ssh -i /root/clave_privada root@localhost
exit
exit
ip a
scp index.php root@192.168.100.35:/root/
scp logo.png root@192.168.100.35:/root/
exit
apt install apache2 -y
apt install php libapache2-mod-php php-mysql -y
clear
ssh -i /root/clave_privada root@localhost
exit
clear
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
nano /var/www/html/test.php
ls -l /var/www/html
curl http://localhost/index.php
clear
ls -l /var/www/html
curl http://localhost/index.php
clear
exit
curl http://localhost/index.php
clear
php -m | grep mysqli
nano /var/www/html/index.php
clear
apt update
apt install mariadb-server -y
systemctl status mariadb
clear
mysql
ls /root
EXIT
exit
cat /etc/os-release 
clear
cat /etc/os-release 
clear
apt install openssh-server -y
systemctl status ssh
nano /etc/ssh/sshd_config
clear
mkdir -p /root/.ssh
chmod 700 /root/.ssh
clear
ip a
systemctl restart ssh
systemctl status ssh
clear
ls /root
mysql < /root/db.sql
mysql
mysql -u lcars -p ingenieria
clear
ip addr
ip route
cat /etc/network/interfaces
clear
cat /etc/network/interfaces
nano /etc/network/interfaces
cat /etc/network/interfaces
reboot
clear
ping deb.debian.org
clear
cat /etc/resolv.conf
exit
lsblk
fdisk -f
fdisk -l
lsblk
df -h
clear
lsblk
fdisk /dev/sdc
fdisk /dev/sdc
clear
fdisk /dev/sdc
lsblk
clear
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
ls
mkdir /www_dir
mkdir /backup_dir
ls -ld /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
ls -l /www_dir
df -h
clear
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
clear
apachectl configtest
systemctl restart apache2
blkid
nano /etc/fstab 
clear
mount -a
df -h
cat /proc/partitions > /opt/partición
reboot
df -h
cat /opt/particion
cat /proc/partitions > /opt/particion
cat /opt/particion
reboot
