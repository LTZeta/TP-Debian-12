#!/bin/bash

# Opción de ayuda
if [ "$1" = "-help" ]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo:"
    echo "$0 /var/log /backup_dir"
    exit 0
fi

# Validar cantidad de parámetros
if [ $# -ne 2 ]; then
    echo "Error: cantidad de parámetros incorrecta."
    echo "Use: $0 -help"
    exit 1
fi

ORIGEN=$1
DESTINO=$2

# Verificar origen
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio origen no existe."
    exit 1
fi

# Verificar destino
if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio destino no existe."
    exit 1
fi

# Obtener nombre del directorio origen
NOMBRE=$(basename "$ORIGEN")

# Fecha ANSI YYYYMMDD
FECHA=$(date +%Y%m%d)

# Nombre del archivo backup
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# Crear backup
tar -czf "${DESTINO}/${ARCHIVO}" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Backup generado: ${DESTINO}/${ARCHIVO}"
else
    echo "Error al generar backup."
    exit 1
fi
